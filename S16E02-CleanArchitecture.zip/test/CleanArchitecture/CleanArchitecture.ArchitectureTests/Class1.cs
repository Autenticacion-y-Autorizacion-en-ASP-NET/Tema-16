﻿namespace CleanArchitecture.ArchitectureTests;

public class Class1
{

}
