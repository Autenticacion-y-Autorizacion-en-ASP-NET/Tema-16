﻿namespace CleanArchitecture.Api.FunctionalTests;

public class Class1
{

}
