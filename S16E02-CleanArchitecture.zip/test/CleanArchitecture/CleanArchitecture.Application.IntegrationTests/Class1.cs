﻿namespace CleanArchitecture.Application.IntegrationTests;

public class Class1
{

}
