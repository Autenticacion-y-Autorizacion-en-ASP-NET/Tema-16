﻿namespace CleanArchitecture.Application.UnitTests;

public class Class1
{

}
